<?php
session_start();
require("config.php");
////code


if (!isset($_SESSION['auser'])) {
	header("location:index.php");
}
?>
<div class="header">
	<style>
		.header {
			background-color: #809668;
		}
	</style>

	<!-- Logo -->
	<div class="header-left">
		<a href="dashboard.php" class="logo">
			<img src="assets/img/Biglogo.png" alt="Logo">
		</a>
		<a href="dashboard.php" class="logo logo-small">
			<img src="assets/img/OARS.png" alt="Logo" width="30" height="30">
		</a>
	</div>
	<!-- /Logo -->

	<a href="javascript:void(0);" id="toggle_btn">
		<i class="fe fe-text-align-left"></i>
	</a>



	<!-- Mobile Menu Toggle -->
	<a class="mobile_btn" id="mobile_btn">
		<i class=""></i>
	</a>
	<!-- /Mobile Menu Toggle -->

	<!-- Header Right Menu -->
	<ul class="nav user-menu">


		<!-- User Menu -->
		<!-- <h4 style="color:white;margin-top:13px;text-transform:capitalize;"><?php echo $_SESSION['auser']; ?></h4> -->
		<li class="nav-item dropdown app-dropdown">
			<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
				<span class="user-img"><img class="rounded-circle" src="assets/img/profiles/avatar-01.png" width="31"
						alt="Ryan Taylor"></span>
			</a>

			<div class="dropdown-menu">
				<div class="user-header">
					<div class="avatar avatar-sm">
						<img src="assets/img/profiles/avatar-01.png" alt="User Image" class="avatar-img rounded-circle">
					</div>
					<div class="user-text">
						<h6><?php echo $_SESSION['auser']; ?></h6>
						<p class="text-muted mb-0">Administrator</p>
					</div>
				</div>
				<a class="dropdown-item" href="profile.php">Profile</a>
				<a class="dropdown-item" href="logout.php">Logout</a>
			</div>
		</li>

		<!-- /User Menu -->

	</ul>
	<!-- /Header Right Menu -->

</div>

<!-- header --->

<style>
	.sidebar {
		background-color: #668096;
	}

	.sidebar-menu ul li a {
		color: #fff;
	}

	.sidebar-menu ul li.menu-title span {
		color: #ffffff;
	}

	.sidebar-menu ul li.submenu ul li a {
		color: #fff;
	}

	.sidebar-menu ul li.submenu ul li a:hover {
		color: #333;
	}
</style>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
	<div class="sidebar-inner slimscroll">
		<div id="sidebar-menu" class="sidebar-menu">
			<ul>
				<li class="menu-title">
					<span>Main</span>
				</li>
				<li>
					<a href="dashboard.php"><i class="fe fe-home"></i> <span>Dashboard</span></a>
				</li>

				<li class="menu-title">
					<span>All Users</span>
				</li>

				<li class="submenu">
					<a href="#"><i class="fe fe-user"></i> <span> All Users </span> <span class="menu-arrow"></span></a>
					<ul style="display: none;">
						<li><a href="adminlist.php"> Admin </a></li>
						<li><a href="student.php"> Student </a></li>
						<li><a href="staff.php"> Staff </a></li>
						<li><a href="member.php"> Member </a></li>
					</ul>
				</li>

				<li class="menu-title">
					<span>Competition</span>
				</li>

				<li class="submenu">
					<a href="#"><i class="fe fe-location"></i> <span>Competition</span> <span
							class="menu-arrow"></span></a>
					<ul style="display: none;">
						<li><a href="competitionadd.php"> Add Competition </a></li>
						<li><a href="competitionview.php"> View Competition </a></li>
					</ul>
				</li>

				<li class="menu-title">
					<span>Event</span>
				</li>
				<li class="submenu">
					<a href="#"><i class="fe fe-map"></i> <span> Event</span> <span class="menu-arrow"></span></a>
					<ul style="display: none;">
						<li><a href="eventadd.php"> Add Event</a></li>
						<li><a href="eventview.php"> View Event </a></li>

					</ul>
				</li>



				<li class="menu-title">
					<span>Query</span>
				</li>
				<li class="submenu">
					<a href="#"><i class="fe fe-comment"></i> <span>Feedback </span> <span
							class="menu-arrow"></span></a>
					<ul style="display: none;">
						<li><a href="feedbackview.php"> Feedback </a></li>
					</ul>
				</li>
				<li class="menu-title">
					<span>About</span>
				</li>
				<li class="submenu">
					<a href="#"><i class="fe fe-browser"></i> <span> About Page </span> <span
							class="menu-arrow"></span></a>
					<ul style="display: none;">
						<li><a href="aboutadd.php"> Add About Content </a></li>
						<li><a href="aboutview.php"> View About </a></li>
					</ul>
				</li>
				<li class="menu-title">
					<span>Notification</span>
				</li>
				
				<li class="submenu">
					<a href="#"><i class="fe fe-mail"></i> <span> News/Announcement </span> <span
							class="menu-arrow"></span></a>
					<ul style="display: none;">
						<li><a href="newsadd.php"> Add News </a></li>
						<li><a href="newsview.php"> News </a></li>
						<li><a href="annoucementview.php"> Announcement </a></li>
					</ul>
				</li>

			</ul>
		</div>
	</div>
</div>
<!-- /Sidebar -->